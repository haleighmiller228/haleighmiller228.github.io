package com.zybooks.inventorytrackerhaleighmiller;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.zybooks.inventorytrackerhaleighmiller.adapters.InventoryAdapter;
import com.zybooks.inventorytrackerhaleighmiller.database.DatabaseHelper;
import com.zybooks.inventorytrackerhaleighmiller.models.InventoryItem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DataGridActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private DatabaseHelper dbHelper;
    private List<InventoryItem> itemList = new ArrayList<>();

    // Phone number to send SMS
    private final String notificationPhoneNumber = "1234567890";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        dbHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        itemList = dbHelper.getAllItems();
        adapter = new InventoryAdapter(itemList, this, dbHelper);
        recyclerView.setAdapter(adapter);

        FloatingActionButton buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonAddItem.setOnClickListener(view -> {
            Intent intent = new Intent(DataGridActivity.this, AddItemActivity.class);
            startActivity(intent);
        });

        Spinner spinnerSort = findViewById(R.id.spinnerSort);

        // Set adapter for spinner
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.sort_options, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSort.setAdapter(spinnerAdapter);

        // Listener for sort changes
        spinnerSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sortItemList(position);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        // Check for low inventory and request/send SMS if needed
        checkInventoryForLowStock(itemList);
    }

    @Override
    protected void onResume() {
        super.onResume();
        itemList.clear();
        itemList.addAll(dbHelper.getAllItems());
        adapter.notifyDataSetChanged();
    }

    private void sortItemList(int sortOption) {
        switch (sortOption) {
            case 0: // Name A-Z
                Collections.sort(itemList, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
                break;
            case 1: // Name Z-A
                Collections.sort(itemList, (a, b) -> b.getName().compareToIgnoreCase(a.getName()));
                break;
            case 2: // Quantity Low-High
                Collections.sort(itemList, Comparator.comparingInt(InventoryItem::getQuantity));
                break;
            case 3: // Quantity High-Low
                Collections.sort(itemList, (a, b) -> b.getQuantity() - a.getQuantity());
                break;
        }

        adapter.notifyDataSetChanged();
    }

    private void checkInventoryForLowStock(List<InventoryItem> items) {
        for (InventoryItem item : items) {
            if (item.getQuantity() <= 2) {
                checkSmsPermissionAndNotify(notificationPhoneNumber,
                        "Inventory alert: '" + item.getName() + "' is low with quantity " + item.getQuantity());
                break;
            }
        }
    }

    private void checkSmsPermissionAndNotify(String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            sendNotificationSms(phoneNumber, message);
        }
    }

    private void sendNotificationSms(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(this, "SMS notification sent!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                          @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied, notifications disabled", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

