package com.zybooks.inventorytrackerhaleighmiller.models;

public class InventoryItem {
    private int id;
    private String name;
    private String details;
    private int quantity;
    private String location;

    public InventoryItem() {
        // Empty constructor
    }

    public InventoryItem(int id, String name, String details, int quantity, String location) {
        this.id = id;
        this.name = name;
        this.details = details;
        this.quantity = quantity;
        this.location = location;
    }

    public InventoryItem(String name, String details, int quantity, String location) {
        this.name = name;
        this.details = details;
        this.quantity = quantity;
        this.location = location;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDetails() {
        return details;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getLocation() {
        return location;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
