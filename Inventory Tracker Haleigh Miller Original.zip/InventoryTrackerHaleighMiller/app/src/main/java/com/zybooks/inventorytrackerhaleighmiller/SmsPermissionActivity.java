package com.zybooks.inventorytrackerhaleighmiller;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.Manifest;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int REQUEST_SMS_PERMISSION = 101;
    private Button buttonSendSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        TextView textPermissionStatus = findViewById(R.id.textPermissionStatus);
        Button buttonRequestPermission = findViewById(R.id.buttonRequestPermission);
        buttonSendSms = findViewById(R.id.buttonSendSms);

        buttonRequestPermission.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        REQUEST_SMS_PERMISSION);
            } else {
                textPermissionStatus.setText("Permission already granted.");
                buttonSendSms.setEnabled(true);
            }
        });

        buttonSendSms.setOnClickListener(view -> {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("1234567890", null,
                    "Inventory Low: Restock soon!", null, null);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                          @NonNull String[] permissions,
                                          @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        TextView textPermissionStatus = findViewById(R.id.textPermissionStatus);

        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                textPermissionStatus.setText("Permission granted.");
                buttonSendSms.setEnabled(true);
            } else {
                textPermissionStatus.setText("Permission denied");
                buttonSendSms.setEnabled(false);
            }
        }
    }
}
