package com.zybooks.inventorytrackerhaleighmiller.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.inventorytrackerhaleighmiller.EditItemActivity;
import com.zybooks.inventorytrackerhaleighmiller.R;
import com.zybooks.inventorytrackerhaleighmiller.models.InventoryItem;
import com.zybooks.inventorytrackerhaleighmiller.database.DatabaseHelper;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private List<InventoryItem> itemList;
    private Context context;
    private DatabaseHelper dbHelper;

    public InventoryAdapter(List<InventoryItem> itemList, Context context, DatabaseHelper dbHelper) {
        this.itemList = itemList;
        this.context = context;
        this.dbHelper = dbHelper;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemDetails;
        ImageButton buttonDelete;

        public ViewHolder(View view) {
            super(view);
            itemName = view.findViewById(R.id.itemName);
            itemDetails = view.findViewById(R.id.itemDetails);
            buttonDelete = view.findViewById(R.id.buttonDelete);
        }
    }

    @NonNull
    @Override
    public InventoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_grid, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryAdapter.ViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);
        holder.itemName.setText(item.getName());
        holder.itemDetails.setText("Qty: " + item.getQuantity() + ", Loc: " + item.getLocation());

        holder.buttonDelete.setOnClickListener(v -> {
            if (position != RecyclerView.NO_POSITION) {
                boolean deleted = dbHelper.deleteItem(item.getId());
                if (deleted) {
                    itemList.remove(position); // remove from list
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, itemList.size());
                    Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Failed to delete item", Toast.LENGTH_SHORT).show();
                }
            }
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditItemActivity.class);
            intent.putExtra("item_id", item.getId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public void updateData(List<InventoryItem> newItemList) {
        itemList.clear();
        itemList.addAll(newItemList);
        notifyDataSetChanged();
    }

}
