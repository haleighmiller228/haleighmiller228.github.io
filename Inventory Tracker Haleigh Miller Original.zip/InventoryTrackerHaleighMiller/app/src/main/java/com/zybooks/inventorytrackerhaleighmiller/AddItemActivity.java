package com.zybooks.inventorytrackerhaleighmiller;

import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import android.Manifest;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.inventorytrackerhaleighmiller.database.DatabaseHelper;
import com.zybooks.inventorytrackerhaleighmiller.models.InventoryItem;

public class AddItemActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;

    private EditText editItemName, editQuantity;
    private Button buttonSaveItem;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        buttonSaveItem = findViewById(R.id.buttonSaveItem);

        dbHelper = new DatabaseHelper(this);

        buttonSaveItem.setOnClickListener(v -> {
            String name = editItemName.getText().toString().trim();
            String quantityStr = editQuantity.getText().toString().trim();

            if (name.isEmpty() || quantityStr.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity;
            try {
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            // Create the item (description/location can be blank for now)
            InventoryItem item = new InventoryItem(name, "", quantity, "");
            dbHelper.insertItem(item);

            Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
            finish(); // Go back to inventory screen

            if (quantity <= 2) {
                String message = "Inventory Alert: Only " + quantity + " left of " + name;
                String testPhoneNumber = "5554";
                checkSmsPermissionAndNotify(testPhoneNumber, message);
            }
        });
    }

    private void checkSmsPermissionAndNotify(String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            sendNotificationSms(phoneNumber, message);
        }
    }

    private void sendNotificationSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low inventory SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
