package com.zybooks.inventorytrackerhaleighmiller;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.inventorytrackerhaleighmiller.database.DatabaseHelper;
import com.zybooks.inventorytrackerhaleighmiller.models.InventoryItem;

public class EditItemActivity extends AppCompatActivity {

    private EditText editName, editQuantity, editLocation;
    private Button buttonUpdate;
    private DatabaseHelper dbHelper;
    private int itemId;
    private InventoryItem item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        editName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        editLocation = findViewById(R.id.editLocation);
        buttonUpdate = findViewById(R.id.buttonUpdateItem);

        dbHelper = new DatabaseHelper(this);
        itemId = getIntent().getIntExtra("item_id", -1);

        item = dbHelper.getItemById(itemId);

        if (item != null) {
            editName.setText(item.getName());
            editQuantity.setText(String.valueOf(item.getQuantity()));
            editLocation.setText(item.getLocation());
        }

        buttonUpdate.setOnClickListener(v -> {
            String name = editName.getText().toString();
            int quantity = Integer.parseInt(editQuantity.getText().toString());
            String location = editLocation.getText().toString();

            item.setName(name);
            item.setQuantity(quantity);
            item.setLocation(location);

            boolean updated = dbHelper.updateItem(item);

            if (updated) {
                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
