//
//  Item+CoreDataClass.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/16/25.
//
//

public import Foundation
public import CoreData

public typealias ItemCoreDataClassSet = NSSet

@objc(Item)
public class Item: NSManagedObject {

}
