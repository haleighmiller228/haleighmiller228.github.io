//
//  InventoryListView.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/14/25.
//

import SwiftUI
import CoreData
import MessageUI

struct InventoryListView: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(
        sortDescriptors: [
            NSSortDescriptor(keyPath: \Item.name, ascending: true),
            NSSortDescriptor(keyPath: \Item.quantity, ascending: true)
        ],
        animation: .default
    )
    private var items: FetchedResults<Item>
    
    private var sortedItems: [Item] {
        items.sorted { lhs, rhs in
            let lhsLow = lhs.quantity <= lhs.threshold
            let rhsLow = rhs.quantity <= rhs.threshold
            
            if lhsLow != rhsLow {
                // Low-stock items first
                return lhsLow && !rhsLow
            } else {
                // Then sort alphabetically by name
                return lhs.name < rhs.name
            }
        }
    }
    
    private var lowStockItems: [Item] {
        sortedItems.filter { $0.quantity <= $0.threshold}
    }
    
    private var reorderEmailBody: String {
        guard !lowStockItems.isEmpty else {
            return "There are currently no low-stock items."
        }
        
        var lines: [String] = []
        lines.append("Hello, \n")
        lines.append("Please reorder the following low-stock items:\n")
        
        for item in lowStockItems {
            let loc = item.location ?? "N/A"
            lines.append("- \(item.name): qty \(item.quantity), " +
                         "threshold \(item.threshold), " +
                         "sold last month \(item.soldLastMonth), " +
                         "location: \(loc)")
        }
        
        lines.append("\nThank you,")
        lines.append("Inventory Tracker App")
        
        return lines.joined(separator: "\n")
    }
    
    @State private var showMailCompose = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(sortedItems) { item in
                    NavigationLink(destination: AddEditItemView(item: item)) {
                        InventoryRowView(item: item)
                    }
                }
                .onDelete(perform: deleteItems)
            }
            .navigationTitle("Inventory")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    EditButton()
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack {
                        NavigationLink(destination: AddEditItemView()) {
                            Image(systemName: "plus")
                        }
                        
                        NavigationLink(destination: EditProfileView()) {
                            Image(systemName: "person.crop.circle")
                        }
                    }
                }
                
                ToolbarItem(placement: .bottomBar) {
                    Button(action: {
                        handleReorder()
                    }) {
                        Label("Reorder / Notify", systemImage: "envelope.badge")
                    }
                }
            }
            .alert("Notifications", isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(alertMessage)
            }
            .sheet(isPresented: $showMailCompose) {
                MailView(
                    subject: "Inventory Reorder Request",
                    body: reorderEmailBody,
                    recipients: ["inventory.manager@example.com"]
                )
            }
        }
    }
    
    private func deleteItems(at offsets: IndexSet) {
        let itemsToDelete = offsets.map { sortedItems[$0] }
        
        for item in itemsToDelete {
            viewContext.delete(item)
        }
        
        do {
            try viewContext.save()
        } catch {
            print("Error deleting item: ", error.localizedDescription)
        }
    }
    
    private func notifyLowStock() {
        print("🔔 Notify Low Stock button tapped")
        
        let lowStockItems = sortedItems.filter { $0.quantity <= $0.threshold }
        
        if lowStockItems.isEmpty {
            alertMessage = "There are no low-stock items right now."
        } else if lowStockItems.count == 1 {
            alertMessage = "Scheduled a notification for 1 low stock item."
        } else {
            alertMessage = "Scheduled notifications for \(lowStockItems.count) low-stock items."
        }
        
        NotificationManager.shared.scheduleLowStockNotifications(for: sortedItems)
        
        // Show the in-app alert
        showAlert = true
    }
    
    private func handleReorder() {
        print("Reorder / Notify tapped")
        let low = lowStockItems
        
        guard !low.isEmpty else {
            alertMessage = "There are no low-stock items to reorder."
            showAlert = true
            return
        }
        
        // 1) Schedule local notifications
        NotificationManager.shared.scheduleLowStockNotifications(for: sortedItems)
        
        // 2) Try to open the email composer
        if MFMailComposeViewController.canSendMail() {
            showMailCompose = true
        } else {
            // Fallback if Mail isn't configured / simulator
            alertMessage = """
            Mail is not set up on this device.

            Here is the reorder message that would be sent:

            \(reorderEmailBody)
            """
            showAlert = true
        }
    }
}

struct InventoryRowView: View {
    @ObservedObject var item: Item
    
    var body: some View {
        HStack {
            if item.quantity <= item.threshold {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.orange)
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name)
                    .font(.headline)
                
                if let desc = item.descriptionText, !desc.isEmpty {
                    Text(desc)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                }
                
                if let loc = item.location, !loc.isEmpty {
                    Text(loc)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Text("Sold last month: \(item.soldLastMonth)")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            VStack {
                if let data = item.photo,
                   let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 44, height: 44)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
            }
            
            Text("\(item.quantity)")
                .monospacedDigit()
                .foregroundColor(item.quantity <= item.threshold ? .red : .primary)
        }
    }
}

#Preview {
    // Preview helper using an in-memory Core Data stack
    let context = PersistenceController.preview.container.viewContext
    return InventoryListView()
        .environment(\.managedObjectContext, context)
}


