//
//  SignUpView.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/21/25.
//

import SwiftUI
import CoreData
import PhotosUI

struct SignUpView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    var onComplete: (User) -> Void
    
    @State private var username = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var errorMessage: String?
    @State private var jobTitle: String = ""
    @State private var department: String = ""
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @State private var photoData: Data? = nil
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Account")) {
                    TextField("Username", text: $username)
                        .autocapitalization(.none)
                    TextField("Email (optional)", text: $email)
                        .keyboardType(.emailAddress)
                    TextField("Job Title", text: $jobTitle)
                    TextField("Department", text: $department)
                }
                
                Section(header: Text("Password")) {
                    SecureField("Password", text: $password)
                    SecureField("Confirm Password", text: $confirmPassword)
                }
                
                if let errorMessage = errorMessage {
                    Section {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }
                }
                
                Section {
                    Button("Create Account") {
                        createAccount()
                    }
                    .disabled(!canCreate)
                }
                
                Section(header: Text("Photo")) {
                    if let data = photoData,
                       let uiImage = UIImage(data: data) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 150)
                            .cornerRadius(8)
                    } else {
                        Text("No photo selected")
                            .foregroundColor(.secondary)
                    }
                    
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                        Label("Select Photo", systemImage: "photo")
                    }
                }
                .onChange(of: selectedPhotoItem) {
                    Task {
                        if let item = selectedPhotoItem,
                           let data = try? await item.loadTransferable(type: Data.self) {
                            photoData = data
                        }
                    }
                }
            }
            .navigationTitle("Create Account")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }
    
    private var canCreate: Bool {
        !username.trimmingCharacters(in: .whitespaces).isEmpty &&
        !password.isEmpty &&
        password == confirmPassword
    }
    
    private func createAccount() {
        // Check username uniqueness
        let request: NSFetchRequest<User> = User.fetchRequest()
        request.predicate = NSPredicate(format: "username == %@", username)
        
        do {
            let existing = try viewContext.fetch(request)
            if !existing.isEmpty {
                errorMessage = "That username is already taken."
                return
            }
            
            let user = User(context: viewContext)
            user.username = username
            user.password = password
            user.email = email.isEmpty ? nil : email
            user.jobTitle = jobTitle.isEmpty ? nil: jobTitle
            user.department = department.isEmpty ? nil: department
            user.photo = photoData
            
            try viewContext.save()
            errorMessage = nil
            onComplete(user)
            dismiss()
        } catch {
            errorMessage = "Could not create account. Please try again."
            print("Sign-up error: \(error.localizedDescription)")
        }
    }
}
