//
//  User+CoreDataClass.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/21/25.
//
//

public import Foundation
public import CoreData

public typealias UserCoreDataClassSet = NSSet

@objc(User)
public class User: NSManagedObject {

}
