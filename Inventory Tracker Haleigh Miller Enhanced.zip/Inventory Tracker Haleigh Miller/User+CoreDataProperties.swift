//
//  User+CoreDataProperties.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/21/25.
//
//

import Foundation
import CoreData

extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        NSFetchRequest<User>(entityName: "User")
    }

    @NSManaged public var username: String
    @NSManaged public var password: String
    @NSManaged public var email: String?
    @NSManaged public var jobTitle: String?
    @NSManaged public var department: String?
    @NSManaged public var photo: Data?

}

extension User : Identifiable {

}
