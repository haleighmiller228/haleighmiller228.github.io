//
//  AddEditItemView.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/14/25.
//

import SwiftUI
import CoreData
import PhotosUI   // for photo picker

struct AddEditItemView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    // If this is non-nil, we're editing an existing item
    var item: Item?
    
    @State private var name: String = ""
    @State private var quantity: String = ""
    @State private var threshold: String = ""
    @State private var location: String = ""
    @State private var descriptionText: String = ""
    @State private var soldLastMonth: String = ""
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @State private var photoData: Data? = nil
    
    @State private var hasLoadedExistingValues = false
    
    var body: some View {
        Form {
            Section(header: Text("Item Details")) {
                TextField("Name", text: $name)
                
                TextField("Quantity", text: $quantity)
                    .keyboardType(.numberPad)
                
                TextField("Low-stock threshold", text: $threshold)
                    .keyboardType(.numberPad)
                
                TextField("Location", text: $location)
                
                TextField("Descripton", text: $descriptionText, axis: .vertical)
                    .lineLimit(2...4)
                
                TextField("Sold in the last month", text: $soldLastMonth)
                    .keyboardType(.numberPad)
            }
            
            Section(header: Text("Photo")) {
                if let data = photoData,
                   let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 150)
                        .cornerRadius(8)
                } else {
                    Text("No photo selected")
                        .foregroundColor(.secondary)
                }
                
                PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                    Label("Select Photo", systemImage: "photo")
                }
            }
            .onChange(of: selectedPhotoItem) {
                Task {
                    if let item = selectedPhotoItem,
                       let data = try? await item.loadTransferable(type: Data.self) {
                        photoData = data
                    }
                }
            }
            
            Section {
                Button(item == nil ? "Add Item" : "Save Changes") {
                    saveItem()
                }
                .disabled(!canSave)
            }
        }
        .navigationTitle(item == nil ? "Add Item" : "Edit Item")
        .onAppear {
            // Pre-fill fields once when editing
            if !hasLoadedExistingValues, let item = item {
                name = item.name
                quantity = String(item.quantity)
                threshold = String(item.threshold)
                location = item.location ?? ""
                descriptionText = item.descriptionText ?? ""
                soldLastMonth = String(item.soldLastMonth)
                photoData = item.photo
                
                hasLoadedExistingValues = true
            }
        }
    }
    
    private var canSave: Bool {
        guard !name.trimmingCharacters(in: .whitespaces).isEmpty,
              Int16(quantity) != nil,
              Int16(threshold) != nil else {
            return false
        }
        
        if !soldLastMonth.isEmpty && Int16(soldLastMonth) == nil {
            return false
        }
        
        return true
    }
    
    private func saveItem() {
        guard let qty = Int16(quantity),
              let th = Int16(threshold) else {
            return
        }
        
        let sold = Int16(soldLastMonth) ?? 0
        
        if let item = item {
            // Edit existing
            item.name = name
            item.quantity = qty
            item.threshold = th
            item.location = location
            item.descriptionText = descriptionText
            item.soldLastMonth = sold
            item.photo = photoData
            
        } else {
            // Create new
            let newItem = Item(context: viewContext)
            newItem.name = name
            newItem.quantity = qty
            newItem.threshold = th
            newItem.location = location
            newItem.descriptionText = descriptionText
            newItem.soldLastMonth = sold
            newItem.photo = photoData
        }
        
        do {
            try viewContext.save()
            dismiss()
        } catch {
            print("Error saving item: \(error.localizedDescription)")
        }
    }
}

#Preview {
    let context = PersistenceController.preview.container.viewContext
    
    // Preview in "add" mode
    return NavigationStack {
        AddEditItemView()
            .environment(\.managedObjectContext, context)
    }
}
