//
//  ContentView.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/14/25.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var isLoggedIn = false
    
    var body: some View {
        if isLoggedIn {
            InventoryListView()
        } else {
            LoginView(onLogin: {
                isLoggedIn = true
            })
        }
    }
}

#Preview {
    let context = PersistenceController.preview.container.viewContext
    return ContentView()
        .environment(\.managedObjectContext, context)
}
