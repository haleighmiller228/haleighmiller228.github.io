//
//  Inventory_Tracker_Haleigh_MillerApp.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/14/25.
//

import SwiftUI
import CoreData
import UserNotifications

@main
struct Inventory_Tracker_Haleigh_MillerApp: App {
    let persistenceController = PersistenceController.shared
    
    init() {
        print("📱 App is starting up")
        // Ask for notification permission on lauch
        NotificationManager.shared.requestAuthorization()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
