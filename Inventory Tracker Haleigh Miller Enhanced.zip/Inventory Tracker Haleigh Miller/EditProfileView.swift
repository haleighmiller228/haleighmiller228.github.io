//
//  EditProfileView.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/26/25.
//

import SwiftUI
import CoreData
import PhotosUI

struct EditProfileView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    @FetchRequest(
        sortDescriptors: [],
        animation: .default
    )
    private var users: FetchedResults<User>
    
    @State private var username: String = ""
    @State private var jobTitle: String = ""
    @State private var department: String = ""
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @State private var photoData: Data? = nil
    
    @State private var hasLoaded = false
    
    private var currentUser: User? {
        users.first
    }
    
    var body: some View {
        Form {
            if currentUser == nil {
                Section {
                    Text("No user found. Please create an account first.")
                        .foregroundColor(.secondary)
                }
            } else {
                Section(header: Text("Account")) {
                    TextField("Username", text: $username)
                        .disabled(true)
                        .foregroundColor(.secondary)
                }
                
                Section(header: Text("Work Details")) {
                    TextField("Job Title", text: $jobTitle)
                    TextField("Department", text: $department)
                }
                
                Section(header: Text("Profile Photo")) {
                    if let data = photoData,
                       let uiImage = UIImage(data: data) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 150)
                            .cornerRadius(8)
                    } else {
                        Text("No photo selected")
                            .foregroundColor(.secondary)
                    }
                    
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                        Label("Select Photo", systemImage: "photo")
                    }
                }
                
                Section {
                    Button("Save Changes") {
                        saveProfile()
                    }
                }
            }
        }
        .navigationTitle("Edit Profile")
        .onAppear {
            loadUserIfNeeded()
        }
        .onChange(of: selectedPhotoItem) {
            Task {
                if let item = selectedPhotoItem,
                   let data = try? await item.loadTransferable(type: Data.self) {
                    photoData = data
                }
            }
        }
    }
    
    private func loadUserIfNeeded () {
        guard !hasLoaded, let user = currentUser else { return }
        
        username = user.username
        jobTitle = user.jobTitle ?? ""
        department = user.department ?? ""
        photoData = user.photo
        
        hasLoaded = true
    }
    
    private func saveProfile() {
        guard let user = currentUser else { return }
        
        user.jobTitle = jobTitle.isEmpty ? nil : jobTitle
        user.department = department.isEmpty ? nil : department
        user.photo = photoData
        
        do {
            try viewContext.save()
            dismiss()
        } catch {
            print("Error saving profile: \(error.localizedDescription)")
        }
    }
}

#Preview {
    let context = PersistenceController.preview.container.viewContext
    return NavigationStack {
        EditProfileView()
            .environment(\.managedObjectContext, context)
    }
}
