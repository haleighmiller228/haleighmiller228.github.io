//
//  Item+CoreDataProperties.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/16/25.
//
//

import Foundation
import CoreData

extension Item {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Item> {
        NSFetchRequest<Item>(entityName: "Item")
    }
    
    @NSManaged public var name: String
    @NSManaged public var quantity: Int16
    @NSManaged public var threshold: Int16
    @NSManaged public var location: String?
    @NSManaged public var descriptionText: String?
    @NSManaged public var photo: Data?
    @NSManaged public var soldLastMonth: Int16
}

extension Item: Identifiable { }
