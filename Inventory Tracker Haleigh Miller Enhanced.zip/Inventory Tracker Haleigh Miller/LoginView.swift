//
//  LoginView.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/14/25.
//

import SwiftUI
import CoreData

struct LoginView: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    var onLogin: () -> Void       // callback when login succeeds
    
    @State private var username = ""
    @State private var password = ""
    @State private var errorMessage: String?
    @State private var showSignUp = false
    @State private var loggedInUser: User?
    
    var body: some View {
        VStack {
            Spacer()
            
            // Title
            VStack(alignment: .leading, spacing: 8) {
                Text("Welcome to Inventory")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                Text("Tracker")
                    .font(.largeTitle)
                    .fontWeight(.bold)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.bottom, 24)
            
            if let user = loggedInUser,
               let data = user.photo,
               let uiImage = UIImage(data: data) {
                
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 100)
                    .clipShape(Circle())
                    .shadow(radius: 4)
                    .padding(.vertical, 16)
            }
            
            // Username field
            HStack {
                Image(systemName: "pencil")
                TextField("Username", text: $username)
                    .autocapitalization(.none)
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(.systemBackground))
                    .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 1)
            )
            
            // Password field
            HStack {
                Image(systemName: "lock.fill")
                SecureField("Password", text: $password)
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(.systemBackground))
                    .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 1)
            )
            .padding(.top, 12)
            
            // Error message
            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .font(.caption)
                    .padding(.top, 8)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            
            // Log In Button (green)
            Button(action: handleLogin) {
                Text("Log In")
                    .fontWeight(.semibold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(24)
            }
            .padding(.top, 24)
            
            // Create Account button (blue)
            Button {
                showSignUp = true
            } label: {
                Text("Create Account")
                    .fontWeight(.semibold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(24)
            }
            .padding(.top, 12)
            
            Spacer()
        }
        .padding()
        .background(Color(.systemGray6))
        .sheet(isPresented: $showSignUp) {
            SignUpView { newUser in
                // Prefill username after signup
                username = newUser.username
            }
            .environment(\.managedObjectContext, viewContext)
        }
    }
    
    private func handleLogin() {
        let request: NSFetchRequest<User> = User.fetchRequest()
        request.predicate = NSPredicate(format: "username == %@", username)
        
        do {
            let users = try viewContext.fetch(request)
            if let user = users.first, user.password == password {
                errorMessage = nil
                loggedInUser = user
                onLogin()
            } else {
                errorMessage = "Invalid username or password."
            }
        } catch {
            errorMessage = "Login failed. Please try again."
            print("Login error: \(error.localizedDescription)")
        }
    }
}

#Preview {
    LoginView(onLogin: {})
}
