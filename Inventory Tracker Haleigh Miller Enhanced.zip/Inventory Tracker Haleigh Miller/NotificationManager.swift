//
//  NotificationManager.swift
//  Inventory Tracker Haleigh Miller
//
//  Created by Haleigh Miller on 11/16/25.
//

import Foundation
import UserNotifications
import CoreData

class NotificationManager {
    static let shared = NotificationManager()
    
    private init() {}
    
    func requestAuthorization() {
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            if let error = error {
                print("Notification auth error: \(error.localizedDescription)")
            } else {
                print("Notifications permission granted: \(granted)")
            }
        }
    }
    
    func scheduleLowStockNotifications(for items: [Item]) {
        let lowStockItems = items.filter { $0.quantity <= $0.threshold }
        
        guard !lowStockItems.isEmpty else {
            print("No low-stock items to notify about.")
            return
        }
        
        print("Scheduling notifications for \(lowStockItems.count) low-stock items")
        
        let center = UNUserNotificationCenter.current()
        
        center.removeAllPendingNotificationRequests()
        
        for item in lowStockItems {
            let content = UNMutableNotificationContent()
            content.title = "Low Stock Alert"
            content.body = "\(item.name) is low on stock (qty: \(item.quantity))."
            content.sound = .default
            
            // Trigger in 5 seconds (simple demo)
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
            
            let request = UNNotificationRequest(
                identifier: "lowStock_\(item.objectID.uriRepresentation().absoluteString)",
                content: content,
                trigger: trigger
            )
            
            center.add(request) { error in
                if let error = error {
                    print("Error scheduling notification: \(error.localizedDescription)")
                } else {
                    print("Scheduled notification for \(item.name)")
                }
            }
        }
    }
}
